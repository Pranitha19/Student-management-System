package com.example.StudentManagementSystem;

import com.example.StudentManagementSystem.entity.Student;
import com.example.StudentManagementSystem.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentManagementSystemApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(StudentManagementSystemApplication.class, args);
	}

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public void run(String... args) throws Exception {
		/* Student s1 = new Student(1L,"pranitha", "Avula", "pranitha@gmail.com");
          studentRepository.save(s1);
		Student s2 = new Student(2L,"Raji", "Pranitha", "rajipranitha@gmail.com");
		studentRepository.save(s2);
		Student s3 = new Student(3L,"Rajendra", "Dabburi", "rajendra@gmail.com");
		studentRepository.save(s3);
	 */
	}
}